<?php
function sendsmsotp($fphone,$otp)
{
    $fphone = $fphone;

//    $sms = "Dear Customer, Your OTP is " . $pwd . ". Use this Passcode to login. Thanks & Regard Bluebeems";
//    $new = str_replace(' ', '%20', $sms);
    //http://ip.shreesms.net/smsserver/sms10n.aspx?UserID=XXXXXXXX&UserPassWord=XXXXXXXXX&PhoneNumber=XXXXXXXXXX&text=XXXXXXXXXXX&GSM=XXXXXX&EntityID=XXXXXXXXXXXX&TemplateID=XXXXXXXXXXXX
    //$url_sms = "http://51.89.173.122/smsserver/SMS10N.aspx?Userid=ADJDAR&UserPassword=12345&PhoneNumber=91" . $fphone . "&Text=$new&GSM=ADJDAR";
    $url_sms = "http://ip.shreesms.net/smsserver/SMS10N.aspx?UserID=BLUBMS&UserPassWord=webknight@2020&PhoneNumber=" . $fphone . "&text=Dear Customer, Your OTP is " . $otp . ". Use this Passcode to login. Thanks %26 Regards Bluebeems&GSM=BLUBMS&EntityID=1701158073121255338&TemplateID=1707162521681084977";
    fopen($url_sms, 'r');
}

?>
