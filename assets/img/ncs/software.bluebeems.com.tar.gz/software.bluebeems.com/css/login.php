<?php
include("header.php");


if (isset($_POST['sendotp'])) {
    $pwd = rand(10000, 99999);
    $phonenumbe = $_POST['phonenumbe'];
    $qry = "INSERT INTO `otp`(`phonenumbe`, `otp`) 
                            VALUES ('$phonenumbe','$pwd')";

    if ($obj->run_qry($qry)) {
        echo "<script>";
        echo "window.location='otp.php?mobilenumber=".$phonenumbe."'";
        echo "</script>";
    }
}

?>
<!-- wrapper  -->
<div id="wrapper">
    <!-- content -->
    <div class="content">
        <!-- column-image  -->
        <div class="column-image">
            <div class="bg" data-bg="images/bg/2.jpg"></div>
            <div class="overlay"></div>
            <div class="column-title">
                <h2>Contact Info</h2>
                <h3>If you'd like to talk about a project, our work or anything else then get in touch.</h3>
            </div>
            <div class="column-notifer" style="height: 55px;">
                <div class="scroll-down-wrap transparent_sdw">
                    <div class="mousey">
                        <div class="scroller"></div>
                    </div>
                    <span>Scroll down  to Discover</span>
                </div>
            </div>
            <div class="fixed-column-dec"></div>
        </div>

        <!-- column-image end  -->
        <!-- column-wrapper -->
        <div class="column-wrapper ">
            <!--scroll-nav-wrap -->
            <div class="scroll-nav-wrap" style="height: 55px;">
                <nav class="scroll-nav scroll-init">
                    <ul>
                        <li style="font-size:larger;"><a class="act-scrlink" href="#sec1"
                            >Details</a></li>
                        <li style="font-size:larger;"><a href="#sec2">Location</a></li>
                        <li style="font-size:larger;"><a href="#sec3">Say Hello</a></li>
                    </ul>
                </nav>
            </div>
            <!--scroll-nav-wrap end-->
            <!--section  -->
            <section id="sec1">
                <div class="container small-container">
                    <div class="section-title fl-wrap">
                        <h3>Login</h3>
                        <!--						<h4>Sed tempor iaculis massa faucibus feugiat. In fermentum facilisis massa</h4>-->
                        <div class="column-wrapper_item fl-wrap">
                            <div class="column-wrapper_text fl-wrap">
                                <div id="contact-form" class="fl-wrap">
                                    <div id="message"></div>
                                    <!--								name="contactform" id="contactform"-->
                                    <form class="custom-form" method="post">
                                        <fieldset>
                                            <div>
                                                <input type="number"
                                                       style="float: left;border: none;border: 1px solid #e4e4e4;background: #fff;width: 100%;padding: 20px 30px;color: #000;font-size: 12px;-webkit-appearance: none;"
                                                       name="phonenumbe" id="mno" required
                                                       placeholder="Your Number *" value=""/>
                                                <button name="sendotp" type="submit"
                                                        class="btn float-btn flat-btn color-bg"
                                                        id="sendotp">Send OTP
                                                </button>
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!--footer -->
            <footer class="min-footer fl-wrap content-animvisible">
                <div class="container small-container">
                    <div class="footer-inner fl-wrap">
                        <!-- policy-box-->
                        <div class="policy-box">
							<span>Made with &#10084; by <a
                                        href="https://www.webknight.co.in/"> WebKnight Infosystem </a> </span>
                        </div>
                        <!-- policy-box end-->
                        <a href="#" class="to-top-btn to-top">Back to top <i class="fal fa-long-arrow-up"></i></a>
                    </div>
                </div>
            </footer>
            <!--footer end  -->
        </div>
        <!-- column-wrapper -->
    </div>
    <!--content end-->
    <!--share-wrapper-->
    <div class="share-wrapper">
        <div class="share-container fl-wrap  isShare"></div>
    </div>
    <!--share-wrapper end-->
</div>
<!-- wrapper end -->
<!-- sidebar -->
<div class="sb-overlay"></div>
<div class="hiiden-sidebar-wrap outsb">
    <!-- sb-widget-wrap-->
    <div class="sb-widget-wrap fl-wrap">
        <h3>SUBSCRIBE TO OUR NEWSLETTER</h3>
        <div class="sb-widget  fl-wrap">
            <p>Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, </p>
            <div class="subcribe-form fl-wrap">
                <form id="subscribe">
                    <input class="enteremail" name="email" id="subscribe-email" placeholder="Your Email"
                           spellcheck="false" type="text">
                    <button type="submit" id="subscribe-button" class="subscribe-button">Submit</button>
                    <label for="subscribe-email" class="subscribe-message"></label>
                </form>
            </div>
        </div>
    </div>
    <!-- sb-widget-wrap end-->
    <!-- sb-widget-wrap-->
    <div class="sb-widget-wrap fl-wrap">
        <h3>We're Are Social</h3>
        <div class="sb-widget    fl-wrap">
            <div class="sidebar-social fl-wrap">
                <ul>
                    <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- sb-widget-wrap end-->
    <!-- sb-widget-wrap-->
    <!--                <div class="sb-widget-wrap fl-wrap">-->
    <!--                    <h3>Our Last Twitts</h3>-->
    <!--                    <div class="sb-widget  fl-wrap">-->
    <!--                        <div id="footer-twiit"></div>-->
    <!--                        <a href="#" target="_blank" class="twitt_btn fl-wrap">Follow Us</a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!-- sb-widget-wrap end-->
</div>
<!-- sidebar end -->
<!-- cursor-->
<div class="element">
    <div class="element-item"></div>
</div>
<!-- cursor end-->
</div>
<!-- Main end -->
<!--=============== scripts  ===============-->

<!--<script type="text/javascript"-->
<!--		src="http://maps.google.com/maps/api/js?key=AIzaSyDwJSRi0zFjDemECmFl9JtRj1FY7TiTRRo"></script>-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/map.js"></script>
<script>
    var url = 'https://wati-integration-service.clare.ai/ShopifyWidget/shopifyWidget.js?37339';
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = url;
    var options = {
        "enabled": true,
        "chatButtonSetting": {
            "backgroundColor": "#4dc247",
            "ctaText": "",
            "borderRadius": "25",
            "marginLeft": "0",
            "marginBottom": "50",
            "marginRight": "50",
            "position": "right"
        },
        "brandSetting": {
            "brandName": "WATI",
            "brandSubTitle": "Typically replies within a day",
            "brandImg": "https://cdn.clare.ai/wati/images/WATI_logo_square_2.png",
            "welcomeText": "Hi, there!\nHow can I help you?",
            "messageText": "Hello, I have a question about {{page_link}}",
            "backgroundColor": "#0a5f54",
            "ctaText": "Start Chat",
            "borderRadius": "25",
            "autoShow": false,
            "phoneNumber": "919879565478"
        }
    };
    s.onload = function () {
        CreateWhatsappChatWidget(options);
    };
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);


</script>
</body>

</html>
