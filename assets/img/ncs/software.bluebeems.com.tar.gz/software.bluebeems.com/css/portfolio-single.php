<?php
include("header.php");

//$qry = "SELECT * FROM `project` where status='1'";
//$res = $obj->run_qry($qry);
?>
            <!-- wrapper  -->	
            <div id="wrapper">
                <div class="content full-height  hidden-item no-mob-hidden">
                    <!-- fw-carousel-wrap -->
                    <div class="fw-carousel-wrap fsc-holder">
                        <!-- fw-carousel  -->
                        <div class="fw-carousel  fs-gallery-wrap fl-wrap full-height lightgallery thumb-contr" data-mousecontrol="true">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide hov_zoom">
                                        <img  src="images/folio/15.jpg"   alt="">
                                        <a href="images/folio/15.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                    </div>
                                    <!-- swiper-slide end-->  
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide hov_zoom">
                                        <img  src="images/folio/2.jpg"   alt="">
                                        <a href="images/folio/2.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                    </div>
                                    <!-- swiper-slide end-->                                      
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide hov_zoom">
                                        <img  src="images/folio/17.jpg"   alt="">
                                        <a href="images/folio/17.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                    </div>
                                    <!-- swiper-slide end--> 
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide hov_zoom">
                                        <img  src="images/folio/4.jpg"   alt="">
                                        <a href="images/folio/4.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                    </div>
                                    <!-- swiper-slide end--> 
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide hov_zoom">
                                        <img  src="images/folio/5.jpg"   alt="">
                                        <a href="images/folio/5.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                    </div>
                                    <!-- swiper-slide end--> 
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide hov_zoom">
                                        <img  src="images/folio/9.jpg"   alt="">
                                        <a href="images/folio/9.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                    </div>
                                    <!-- swiper-slide end--> 
                                    <!-- swiper-slide-->  
                                    <div class="swiper-slide swiper-link-wrap hov_zoom">
                                        <img  src="images/folio/19.jpg"   alt="">
                                        <a href="images/folio/19.jpg" class="box-media-zoom   popup-image"><i class="fal fa-search"></i></a>
                                        <a href="portfolio-single.html" class="swiper-link"><span>Next Album Title</span></a>                                     
                                    </div>
                                    <!-- swiper-slide end-->   
                                </div>
                            </div>
                        </div>
                        <!-- fw-carousel end -->
                    </div>
                    <!--slider-counter-->	
                    <div class="slider-counter_wrap">
                        <div class="fw-carousel-counter"></div>
                    </div>
                    <!--slider-counter end-->	
                    <!--bottom-panel-->	
                    <div class="bottom-panel single-carousel-control">
                        <div class="bottom-panel-column bottom-panel-column_left fix-size">
                            <div class="single-carousel-control_list">
                                <ul>
                                    <li class="show_thumbnails unvisthum">Show Thumbnails</li>
                                    <li class="decl shibtn unvisthum2">View Details</li>
                                </ul>
                            </div>
                            <div class="fs-controls_wrap">
                                <div class="fw_cb fw-carousel-button-prev"><i class="fal fa-angle-left"></i></div>
                                <div class="fw_cb fw-carousel-button-next"><i class="fal fa-angle-right"></i></div>
                            </div>
                        </div>
                        <div class="bottom-panel-column bottom-panel-column_right fix-size">
                            <div class="half-scrollbar">
                                <div class="hs_init"></div>
                            </div>
                        </div>
                    </div>
                    <!--bottom-panel end-->	
                </div>
                <!--content end-->	
                <!-- project details -->
                <div class="det-overlay act-closedet"></div>
                <div class="fix-pr-det hid-det hid-det-anim">
                    <div class="act-closedet closedet_style det-anim"><i class="fal fa-long-arrow-left"></i></div>
                    <div class="pr-det-container initscroll">
                        <div class="fl-wrap det-anim">
                            <h2>Welcome To New York</h2>
                            <span class="separator sep-b"></span>
                            <div class="clearfix"></div>
                            <p>Nulla scelerisque, enim id elementum suscipit, magna odio fermentum arcu, nec dictum nibh nibh et magna. </p>
                            <p>Praesent nec leo venenatis elit semper aliquet id ac enim. Maecenas nec mi leo. Etiam venenatis ut dui non hendrerit. Integer dictum, diam vitae blandit accumsan, dolor odio tempus arcu, vel ultrices nisi nibh vitae ligula.</p>
                            <p>Nulla scelerisque, enim id elementum suscipit, magna odio fermentum arcu, nec dictum nibh nibh et magna. </p>
                        </div>
                        <div class="caption-wrap fl-wrap det-anim">
                            <ul>
                                <li>
                                    <span>Location</span>
                                    <a href="#">NY , USA</a>
                                </li>
                                <li>
                                    <span>Category</span>
                                    <a href="#">Travel</a>
                                </li>
                                <li>
                                    <span>Model</span>
                                    <a href="#">Austin Onishe</a>
                                </li>
                                <li>
                                    <span>Camera</span>
                                    <a href="#">Canon 6d</a>
                                </li>
                            </ul>
                        </div>
                        <a href="#" class="btn fl-btn det-anim" target="_blank">View Project</a>
                        <div class="content-nav det-anim">
                            <ul>
                                <li><a href="portfolio-single.html" class="ajax ln"><i class="fal fa-angle-left"></i><span class="tooltip">Prev - Project Title</span></a></li>
                                <li><a href="portfolio-single2.html" class="ajax rn"><i class="fal fa-angle-right"></i><span class="tooltip">Next - Project Title</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- project details  end-->
                <!--thumbnail-container-->	
                <div class="thumbnail-container">
                    <div class="thumbnail-wrap fl-wrap">
                    </div>
                </div>
                <!--thumbnail-container end-->	
                <!--share-wrapper-->
                <div class="share-wrapper">
                    <div class="share-container fl-wrap  isShare"></div>
                </div>
                <!--share-wrapper end-->
            </div>
            <!-- wrapper end -->
            <!-- sidebar -->
            <div class="sb-overlay"></div>
            <div class="hiiden-sidebar-wrap outsb">
                <!-- sb-widget-wrap-->
                <div class="sb-widget-wrap fl-wrap">
                    <h3>SUBSCRIBE TO OUR NEWSLETTER</h3>
                    <div class="sb-widget  fl-wrap">
                        <p>Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet,  </p>
                        <div class="subcribe-form fl-wrap">
                            <form id="subscribe">
                                <input class="enteremail" name="email" id="subscribe-email" placeholder="Your Email" spellcheck="false" type="text">
                                <button type="submit" id="subscribe-button" class="subscribe-button">Submit</button>
                                <label for="subscribe-email" class="subscribe-message"></label>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- sb-widget-wrap end-->  
                <!-- sb-widget-wrap-->
                <div class="sb-widget-wrap fl-wrap">
                    <h3>We're Are Social</h3>
                    <div class="sb-widget    fl-wrap">
                        <div class="sidebar-social fl-wrap">
                            <ul>
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- sb-widget-wrap end-->                                   
                <!-- sb-widget-wrap-->
                <div class="sb-widget-wrap fl-wrap">
                    <h3>Our Last Twitts</h3>
                    <div class="sb-widget  fl-wrap">
                        <div id="footer-twiit"></div>
                        <a href="#" target="_blank" class="twitt_btn fl-wrap">Follow Us</a>
                    </div>
                </div>
                <!-- sb-widget-wrap end-->    
            </div>
            <!-- sidebar end -->
            <!-- cursor-->
            <div class="element">
                <div class="element-item"></div>
            </div>
            <!-- cursor end-->          
        </div>
        <!-- Main end -->
        <!--=============== scripts  ===============-->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>
        <script type="text/javascript" src="js/scripts.js"></script>
<script>
    var url = 'https://wati-integration-service.clare.ai/ShopifyWidget/shopifyWidget.js?37339';
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = url;
    var options = {
        "enabled":true,
        "chatButtonSetting":{
            "backgroundColor":"#4dc247",
            "ctaText":"",
            "borderRadius":"25",
            "marginLeft":"0",
            "marginBottom":"50",
            "marginRight":"50",
            "position":"right"
        },
        "brandSetting":{
            "brandName":"WATI",
            "brandSubTitle":"Typically replies within a day",
            "brandImg":"https://cdn.clare.ai/wati/images/WATI_logo_square_2.png",
            "welcomeText":"Hi, there!\nHow can I help you?",
            "messageText":"Hello, I have a question about {{page_link}}",
            "backgroundColor":"#0a5f54",
            "ctaText":"Start Chat",
            "borderRadius":"25",
            "autoShow":false,
            "phoneNumber":"919879565478"
        }
    };
    s.onload = function() {
        CreateWhatsappChatWidget(options);
    };
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);
</script>
    </body>

<!-- Mirrored from kotlis.kwst.net/light/portfolio-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 May 2021 07:27:20 GMT -->
</html>
