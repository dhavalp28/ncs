<?php
//header("Access-Control-Allow-Origin: *");
session_start();

include("header.php");
include('send_sms.php');
if(isset($_COOKIE['showPopup']))
{
    echo 'Not show pop';
}
?>
<!-- wrapper  -->
<div id="wrapper">
    <!-- content -->
    <div class="content">
        <!-- column-image  -->
        <div class="column-image">
            <div class="bg" data-bg="images/bg/2.jpg"></div>
            <div class="overlay"></div>
            <div class="column-title">
                <h2>Login</h2>

            </div>
            <div class="column-notifer" style="height: 55px;">
                <div class="scroll-down-wrap transparent_sdw">
                    <div class="mousey">
                        <div class="scroller"></div>
                    </div>
                    <span>Scroll down  to Discover</span>
                </div>
            </div>
            <div class="fixed-column-dec"></div>
        </div>

        <!-- column-image end  -->
        <!-- column-wrapper -->
        <div class="column-wrapper ">
            <section id="sec3" style="padding:20px 0;">
                <div class="container small-container">
                    <div class="section-title fl-wrap">
                        <h3>Login</h3>
                        <!--						<h4>Sed tempor iaculis massa faucibus feugiat. In fermentum facilisis massa</h4>-->
                        <div class="section-number">01.</div>
                    </div>
                    <div class="column-wrapper_item fl-wrap">
                        <div class="column-wrapper_text fl-wrap">
                            <div id="contact-form" class="fl-wrap">
                                <!--								name="contactform" id="contactform"-->
                                <!-- <form class="custom-form" method="post" action="" onsubmit="return do_login();">-->
                                <fieldset>
                                    <div>
                                        <?php

                                        if (isset($_POST['send_otp'])) {
                                            ?>
                                            <form class="custom-form" name="form" action="" method="post">

                                                <input type="number"
                                                       style="float: left;border: none;border: 1px solid #e4e4e4;background: #fff;width: 100%;padding: 20px 30px;color: #000;font-size: 12px;-webkit-appearance: none;"
                                                       name="phonenumber" value="<?php echo $_POST['phonenumber']; ?>"
                                                       readonly id="phonenumber" required
                                                       placeholder="Your Number *"/>

                                            </form>
                                            <?php
                                            error_reporting(0);

                                            $otp = rand(1000, 9999);
                                            $phone = $_POST['phonenumber'];

                                            $_SESSION['phone'] = $phone;
                                            $_SESSION['otp'] = $otp;

                                            $date = date('d-m-y');
                                            $time = time();

                                            $select = $obj->run_qry("select * from user where mobno = '$phone' ");
                                            $record = mysqli_fetch_array($select);
                                            $num_rows = mysqli_num_rows($select);

                                            if ($num_rows > 0) {

                                                $insert = $obj->run_qry("update user set otp='$otp', time_e='0' where mobno='$phone'");

                                                $url = "http://ip.shreesms.net/smsserver/SMS10N.aspx?UserID=BLUBMS&UserPassWord=webknight@2020&PhoneNumber=" . $phone . "&text=Dear%20Customer,%20Your%20OTP%20is%20" . $otp . ".%20Use%20this%20Passcode%20%20to%20login.%20Thanks%20Regards%20Bluebeems&GSM=BLUBMS&EntityID=1701158073121255338&TemplateID=1707162521681084977";

                                                $ch = curl_init();

                                                curl_setopt($ch, CURLOPT_URL, $url);

                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

                                                curl_setopt($ch, CURLOPT_POST, 1);

                                                // curl_setopt($ch, CURLOPT_POSTFIELDS, $request);

                                                $response = curl_exec($ch);

                                                curl_close($ch);

                                                sendsmsotp($phone, $otp);
                                            } else {

                                                $mobno = $record['mobno'];
                                                $otpno = $record['otp'];

                                                $insert = $obj->run_qry("insert into user(mobno,otp,date_d,time_t,time_e) values('$phone','$otp','$date','$time','0') ");


                                                $url = "http://ip.shreesms.net/smsserver/SMS10N.aspx?UserID=BLUBMS&UserPassWord=webknight@2020&PhoneNumber=" . $phone . "&text=Dear%20Customer,%20Your%20OTP%20is%20" . $otp . ".%20Use%20this%20Passcode%20%20to%20login.%20Thanks%20Regards%20Bluebeems&GSM=BLUBMS&EntityID=1701158073121255338&TemplateID=1707162521681084977";

                                                $ch = curl_init();

                                                curl_setopt($ch, CURLOPT_URL, $url);

                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

                                                curl_setopt($ch, CURLOPT_POST, 1);

                                                // curl_setopt($ch, CURLOPT_POSTFIELDS, $request);

                                                $response = curl_exec($ch);

                                                curl_close($ch);

                                                sendsmsotp($phone, $otp);
                                            }
                                        } else {
                                            ?>
                                            <form class="custom-form" name="form" method="post">

                                                <input type="text" pattern="[0-9]{10}" title="10 Digits mobile number" maxlength="10"
                                                       style="float: left;border: none;border: 1px solid #e4e4e4;background: #fff;width: 100%;padding: 20px 30px;color: #000;font-size: 12px;-webkit-appearance: none;"
                                                       name="phonenumber" id="phonenumber" required placeholder="Your Number *"/>

                                                <?php //echo $_COOKIE['phone']; ?>

                                                <button name="send_otp" type="submit"
                                                        class="btn float-btn flat-btn color-bg"
                                                        id="">Send OTP
                                                </button>

                                            </form>

                                            <?php
                                        }
                                        ?>

                                    </div>

                                    <?php

                                    if (isset($_POST['btn_submit'])) {

                                        $otpno1 = $_POST['otp'];

                                        // order by id desc limit 1

                                        $select = $obj->run_qry("select * from user where otp = '$otpno1' and time_e='0' ");
                                        $record = mysqli_fetch_array($select);
                                        $num_rows = mysqli_num_rows($select);
                                        $mobno = $record['mobno'];
                                        $otpno = $record['otp'];
                                        $_SESSION['phone'] = $record['mobno'];

                                        $id = $record['id'];

                                        $date_otp = date('d-m-y');
                                        $time_otp = time();

                                        if ($num_rows == 1) {

                                            $update = $obj->run_qry("update user set time_e = '1' where otp = '$otpno' ");
                                            setcookie('showstuff', true,  time()+86400); // 1 day
                                            $_SESSION['phone'] = $record['mobno'];
                                            echo "<script> location.href='index.php'; </script>";
                                        } else {

                                            unset($_SESSION['phone']);
                                            echo "<script> alert('Wrong OTP Entered,Try Again..'); </script>";
                                        }
                                    }
                                    ?>

                                    <form method="post" class="custom-form" name="form" action="">

                                        <input type="number"
                                               style="float: left;border: none;border: 1px solid #e4e4e4;background: #fff;width: 100%;padding: 20px 30px;color: #000;font-size: 12px;-webkit-appearance: none;"
                                               name="otp" id="otp" required
                                               placeholder="Enter OTP *" value=""/>

                                        <button name="btn_submit" type="submit"
                                                class="btn float-btn flat-btn color-bg"
                                                id="">Get in
                                        </button>
                                    </form>

                            </div>
                            </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
        </div>
        </section>
        <div>
            <!--section end  -->
            <!--footer -->
            <footer class="min-footer fl-wrap content-animvisible">
                <div class="container small-container">
                    <div class="footer-inner fl-wrap">
                        <!-- policy-box-->
                        <div class="policy-box">
							<span>Made with &#10084; by <a
                                        href="https://www.webknight.co.in/"> WebKnight Infosystem </a> </span>
                        </div>
                        <!-- policy-box end-->
                        <a href="#" class="to-top-btn to-top">Back to top <i class="fal fa-long-arrow-up"></i></a>
                    </div>
                </div>
            </footer>
            <!--footer end  -->
        </div>
        <!-- column-wrapper -->
    </div>
    <!--content end-->
    <!--share-wrapper-->
    <div class="share-wrapper">
        <div class="share-container fl-wrap  isShare"></div>
    </div>
    <!--share-wrapper end-->
</div>
<!-- wrapper end -->
<!-- sidebar -->
<div class="sb-overlay"></div>
<div class="hiiden-sidebar-wrap outsb">
    <!-- sb-widget-wrap-->
    <div class="sb-widget-wrap fl-wrap">
        <h3>SUBSCRIBE TO OUR NEWSLETTER</h3>
        <div class="sb-widget  fl-wrap">
            <p>Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, </p>
            <div class="subcribe-form fl-wrap">
                <form id="subscribe">
                    <input class="enteremail" name="email" id="subscribe-email" placeholder="Your Email"
                           spellcheck="false" type="text">
                    <button type="submit" id="subscribe-button" class="subscribe-button">Submit</button>
                    <label for="subscribe-email" class="subscribe-message"></label>
                </form>
            </div>
        </div>
    </div>
    <!-- sb-widget-wrap end-->
    <!-- sb-widget-wrap-->
    <div class="sb-widget-wrap fl-wrap">
        <h3>We're Are Social</h3>
        <div class="sb-widget    fl-wrap">
            <div class="sidebar-social fl-wrap">
                <ul>
                    <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- sb-widget-wrap end-->
    <!-- sb-widget-wrap-->
    <!--                <div class="sb-widget-wrap fl-wrap">-->
    <!--                    <h3>Our Last Twitts</h3>-->
    <!--                    <div class="sb-widget  fl-wrap">-->
    <!--                        <div id="footer-twiit"></div>-->
    <!--                        <a href="#" target="_blank" class="twitt_btn fl-wrap">Follow Us</a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!-- sb-widget-wrap end-->
</div>
<!-- sidebar end -->
<!-- cursor-->
<div class="element">
    <div class="element-item"></div>
</div>
<!-- cursor end-->
</div>
<!-- Main end -->
<!--=============== scripts  ===============-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/map.js"></script>
<script>
    function do_login() {
        var email = $("#phonenumber").val();
        if (email != "") {
            $.ajax
            ({
                type: 'post',
                url: 'login_api.php',
                data: {
                    phonenumber: email
                },
                success: function (response) {
                    alert(response);
                    if (response == "success") {
                        window.location.href = "index.php";
                    } else {
                        alert("Wrong Details");
                    }
                }
            });
        } else {
            alert("Please Fill All The Details");
        }

        return false;
    }

    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    }


    function checkhapta() {
        var captch_1 = $("#captch_1").val();
        var captch_2 = $("#captch_2").val();
        var captch = $("#captcha").val();

        var total = parseInt(captch_1) + parseInt(captch_2);

        if (total == captch) {
            $("#myText").html("Your answer to the Math Question is correct.").show();
            $("#myText1").hide();
        } else {
            $("#myText").hide();
            $("#myText1").html("Your answer to the Math Question is incorrect.").show();
        }
    }

    $("#searcharea").keyup(function () {
        _this = this.value.toLowerCase();
        $(".filterme").each(function (index) {
            if (this.className.toLowerCase().indexOf(_this) == -1) {
                $(this).hide();
            } else {
                $(this).show();
            }
        });

    });

    function searcharea(serachname) {
        if (serachname == "") {
            $("#getaddvalue").show();
            $("#searchvalue").hide();
        } else {
            $.ajax({
                url: "seracharea.php",
                method: "POST",
                data: {
                    search_id: serachname
                },
                complete: function () {
                },
                success: function (data) {
                    console.log(data)
                    var str = data;
                    var res = str.split("***");

                    if (res[0] === "done") {
                        $("#searchvalue").html(res[1]);
                        $("#searchvalue").show();
                        $("#getaddvalue").hide();
                    } else {
                        $("#searchvalue").html(data);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        alert('Internal error: ' + jqXHR.responseText);
                    } else {
                        alert('Unexpected error.');
                    }
                }
            });
        }
    }
</script>


<!--<script type="text/javascript"-->
<!--		src="http://maps.google.com/maps/api/js?key=AIzaSyDwJSRi0zFjDemECmFl9JtRj1FY7TiTRRo"></script>-->

<script>
    var url = 'https://wati-integration-service.clare.ai/ShopifyWidget/shopifyWidget.js?37339';
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = url;
    var options = {
        "enabled": true,
        "chatButtonSetting": {
            "backgroundColor": "#4dc247",
            "ctaText": "",
            "borderRadius": "25",
            "marginLeft": "0",
            "marginBottom": "50",
            "marginRight": "50",
            "position": "right"
        },
        "brandSetting": {
            "brandName": "WATI",
            "brandSubTitle": "Typically replies within a day",
            "brandImg": "https://cdn.clare.ai/wati/images/WATI_logo_square_2.png",
            "welcomeText": "Hi, there!\nHow can I help you?",
            "messageText": "Hello, I have a question about {{page_link}}",
            "backgroundColor": "#0a5f54",
            "ctaText": "Start Chat",
            "borderRadius": "25",
            "autoShow": false,
            "phoneNumber": "919879565478"
        }
    };
    s.onload = function () {
        CreateWhatsappChatWidget(options);
    };
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);


</script>
<!--
<script>
       
    phone = document.forms["form"]["phonenumber"].value;    
    otp = document.forms["form"]["otp"].value;
    
    if(phone == "" && otp == ""){
        
        alert('fill the phone no and otp first...');
    }
    
    
</script>
-->
</body>

<!-- Mirrored from kotlis.kwst.net/light/contacts.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 May 2021 07:27:06 GMT -->
</html>
