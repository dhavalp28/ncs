var stage=0;
var soc=0;
var sol=0;
var ltracker=0;
var totReturn=0;
var totReturn_tracker=0;
var stage_2_inner=0;
var stage_3_inner=0;
var intervalId;
var vartemp=0;
var obj = document.querySelector('.preloader'),
  inner = document.querySelector('.preloader_inner'),
  page = document.querySelector('.page');
var $PER=0;
function connectToBle() {
  // Connect to a device by passing the service UUID
  if(manage_validation()){
    blueTooth.connect(0xFFE0, gotCharacteristics);
  }else{
    alert("Please enter all necessary detail");
    return 0;
  }
}


// A function that will be called once got characteristics
function gotCharacteristics(error, characteristics) {
  if (error) { 
    console.log('error: ', error);
  }
  console.log('characteristics: ', characteristics);
  blueToothCharacteristic = characteristics[0];

  blueTooth.startNotifications(blueToothCharacteristic, gotValue, 'string');
  
  isConnected = blueTooth.isConnected();
    
  intervalId = window.setInterval(function(){
    
    var CON='{"CON":0}';
    sendData(CON);
    
  }, 1000);
    
  
  // Add a event handler when the device is disconnected
  blueTooth.onDisconnected(onDisconnected);
}



// A function that will be called once got values
async function gotValue(value) {
  console.log('value: ', value);
  if (value == '{"CON":1}') {
    clearInterval(intervalId) 
    load_per(); 
    var ERASE='{"ERASE":1}';
    stage=1;
    $PER=1;
    soc=0;
    sol=0;
    ltracker=0;
    totReturn=fetch_total_datatosend();
    totReturn_tracker=0;
    stage_3_inner=0;
    stage_2_inner=0;
    sendData(ERASE);
    show_percentage($PER);
  } else if(value == '{"ACK":"OK"}'){
    totReturn_tracker++;
    if(totReturn<totReturn_tracker){
        $PER=100;
    }else{
    $PER=Math.floor((100 * totReturn_tracker) / totReturn);
        
    }
    show_percentage($PER);
    if(stage==1){
      var SOP='{"SOP":"1"}';
      stage=2;
      sendData(SOP);
    }else if(stage==2){
      $rv = document.getElementById("row_val").value;
      $cv = document.getElementById("col_val").value;
      $Start_time = document.getElementById("Start_time").value;
      $stimeh=convertTime12to24h($Start_time);
      $stimem=convertTime12to24m($Start_time);
      $Stop_time = document.getElementById("Stop_time").value;
      $etimeh=convertTime12to24h($Stop_time);
      $etimem=convertTime12to24m($Stop_time);
      $tno = document.getElementById("tabl_no").value;
      var $tno_p = $tno.split(",");

      $char = $tno_p.length - 1;
          var CONFIG_DATA="";  
        if(stage_2_inner==0){
          CONFIG_DATA='{"ROW":'+$rv+',"COL":'+$cv+'}';
          stage_2_inner=1;
        }else if(stage_2_inner==1){
            CONFIG_DATA='{"CHAR":'+$char+'}';
            stage_2_inner=2;
        }else if(stage_2_inner==2){
          CONFIG_DATA='{"SH":'+$stimeh+',"SM":'+$stimem+'}';
          stage_2_inner=3;
        }else if(stage_2_inner==3){
          CONFIG_DATA='{"EH":'+$etimeh+',"EM":'+$etimem+'}';
          stage_2_inner=4;
        }else if(stage_2_inner==4){
          var d = new Date();
          var n2 = d.getHours();
          var n = d.getMinutes();
          CONFIG_DATA='{"CH":'+n2+',"CM":'+n+'}';
          stage_2_inner=0;
          stage=3;
        }
      sendData(CONFIG_DATA);
    }else if(stage==3){
      $tno = document.getElementById("tabl_no").value;
      var $tno_ps = $tno.split(",");
      var $char = $tno_ps.length - 1;
     if(stage_3_inner==0){ soc++; }
      if(soc>$char){
        stage=0;
        soc=0;
        sol=0;
        ltracker=0;
        $per=100;
        totReturn_tracker=0;
        totReturn=0;
          inner.textContent = 'Sending 100 %';
          
            await new Promise(resolve => setTimeout(resolve, 1000));
       alert("Data sent successfully");
       blueTooth.disconnect();
       inner.textContent = 'Sending 0 %';
       
      }else{
        var settlement_soc2=soc-1;
        $rd=document.getElementById("row_d_" + $tno_ps[settlement_soc2]).value;
        $pd=document.getElementById("prg_d_" + $tno_ps[settlement_soc2]).value;
        $fd=document.getElementById("fd_" + $tno_ps[settlement_soc2]).value;
        $fdm=document.getElementById("fade_d_" + $tno_ps[settlement_soc2]).value;
        var CHAR_DATA="";
        if(stage_3_inner==0){
            CHAR_DATA='{"SC":'+soc+',"RD":'+$rd+'}';
            stage_3_inner=1;
        }else if(stage_3_inner==1){
            CHAR_DATA='{"PD":'+$pd+',"FD":'+$fd+'}';
            stage_3_inner=2;
        }else if(stage_3_inner==2){
            CHAR_DATA='{"FDM":'+$fdm+'}';
            stage_3_inner=0;
            stage=4;
        }
        
        // var CHAR_DATA='{"SOC":'+soc+',"RD":'+$rd+',"PD":'+$pd+',"FD":'+$fd+',"FDM":'+$fdm+'}';
        sendData(CHAR_DATA);
      }
    }else if(stage==4){
      $rv = document.getElementById("row_val").value;
      $cv = document.getElementById("col_val").value;
      sol++;
      if(sol>$rv){
        var EOP='{"EOP":'+soc+'}';
        stage=3;
        sol=0;
        sendData(EOP); 
      }else{
        var LINE_DATA='{"SOL":'+sol+'}';
        stage=5;
        sendData(LINE_DATA);
      }
    }else if(stage==5){
      $cv = document.getElementById("col_val").value;
      $tno = document.getElementById("tabl_no").value;
      var $tno_ps_n = $tno.split(",");
      var settlement_soc_n=soc-1;
      $jk="";
      for (var ci = 1; ci <= $cv; ci++) {
        var did = $tno_ps_n[settlement_soc_n] + "_" + sol + "_" + ci;
        $jk += document.getElementById(did).innerHTML;
      }
      $jk_array=find_byte_array($jk);
      
      if(ltracker==$jk_array.length){
        var LINE_DATA2='{"EOL":'+sol+'}';
        stage=4;
        
        ltracker=0;
        sendData(LINE_DATA2);
      }else{
          var ltrackertoshow=ltracker+1;
        var ROW_DATA='{"BT":'+ ltrackertoshow +',"DT":'+$jk_array[ltracker]+'}';
        stage=5;
            ltracker++;
        sendData(ROW_DATA);
      }
    }
  }
}

function load_per(){
      obj.classList.add('show');
  page.classList.remove('show');
  
}

function show_percentage(w){
    console.log(w);
    if(w<0)
    {
        inner.textContent = 'Sending 1 %'
    }
    else if(w>100)
    {
        inner.textContent = 'Sending 99 %'
    }else {
        inner.textContent = 'Sending '+ w +' %'
    }
    
    // if (w === 100) {
    //   inner.textContent = 'Sending 0 %';
    //   obj.classList.remove('show');
    //   page.classList.add('show');
    // }
}

function find_byte_array($string_data) {
    if(String($string_data).length>8){
  $find_mod= String($string_data).length % 8;      
    }else{
  $find_mod= 8 % String($string_data).length;
    }
  $string_data=String($string_data);
  for (var mod_loop=0;mod_loop<$find_mod;mod_loop++){
    $string_data+="0";
  }
  $string_data=String($string_data);
  $farray=$string_data.match(/.{1,8}/g);
  $rstring_array=[];
  for ($fg=0;$fg<$farray.length;$fg++){
      $rstring=$farray[$fg].split("").reverse().join("");
      //$rstring_array[$fg]=bin2hex($rstring).toUpperCase();;
      $rstring_array[$fg]=parseInt($rstring, 2);
  }

  return $rstring_array;
}

function bin2hex(b) {
  return b.match(/.{4}/g).reduce(function(acc, i) {
    return acc + parseInt(i, 2).toString(16);
  }, '')
}

const convertTime12to24h = (time12h) => {
  const [time, modifier] = time12h.split(' ');

  let [hours, minutes] = time.split(':');

  if (hours === '12') {
    hours = '00';
  }

  if (modifier === 'PM') {
    hours = parseInt(hours, 10) + 12;
  }
  hours=parseInt(hours);
  minutes=parseInt(minutes);
  
  if(hours==0 && minutes==0){
     return 0;
  }else{
    return `${hours}`;   
  }
}

const convertTime12to24m = (time12h) => {
  const [time, modifier] = time12h.split(' ');

  let [hours, minutes] = time.split(':');

  if (hours === '12') {
    hours = '00';
  }

  if (modifier === 'PM') {
    hours = parseInt(hours, 10) + 12;
  }
  hours=parseInt(hours);
  minutes=parseInt(minutes);
  
  if(hours==0 && minutes==0){
     return 0;
  }else{
    return `${minutes}`;   
  }
}

function fetch_total_datatosend(){
    $rv = document.getElementById("row_val").value;
    $cv = document.getElementById("col_val").value;
    $tno = document.getElementById("tabl_no").value;
      var $tno_p = $tno.split(",");
    
      $char = $tno_p.length - 1;  
      
      if($cv>8){
    $find_d_r_s=Math.ceil($cv / 8);      
      }else{
          $find_d_r_s=Math.ceil(8/$cv);
      }
    
    $tot_return=2 + ($char * 8) + ($char * $rv * 2) + ($char * $rv * $find_d_r_s)   
    return $tot_return;
}


function cancelsending() {
  console.log('Device got disconnected.');
  vartemp=1;
  blueTooth.disconnect();
  
}


function onDisconnected() {
    
  console.log('Device got disconnected.');
    stage=0;
    soc=0;
    sol=0;
    ltracker=0;
    totReturn_tracker=0;
    totReturn=0;
    isConnected = false;
    
  
      obj.classList.remove('show');
      page.classList.add('show');
     inner.textContent = 'Sending 0 %';
      
  
  if(vartemp==0 && $per<100){
          alert("Bluetooth connection lost");
      }
  if(vartemp==1){
      alert("Cancel sending sucessfully....");
      vartemp=0;
  }
  
}


function sendData(command) {
  const inputValue = command;
  if (!("TextEncoder" in window)) {
    console.log("Sorry, this browser does not support TextEncoder...");
  }
  var enc = new TextEncoder(); // always utf-8
 
  blueToothCharacteristic.writeValue(enc.encode(inputValue));
}
