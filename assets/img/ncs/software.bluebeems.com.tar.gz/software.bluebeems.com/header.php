<?php
include("conn.php");

$filel = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
?>
 
<!DOCTYPE HTML>
<html lang="en">

<head>
    <!--=============== basic  ===============-->
    <meta charset="UTF-8">
    <title>Bluebeems</title>
    
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content="Bluebeems"/>
    <meta name="description" content="Bluebeems"/>
    <!--=============== css  ===============-->
    <link type="text/css" rel="stylesheet" href="css/reset.css">
    <link type="text/css" rel="stylesheet" href="css/plugins.css">
    <link type="text/css" rel="stylesheet" href="css/style.css">
    <!--=============== favicons ===============-->
    <link rel="shortcut icon" href="images/bluebeems_logo.png">
        
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-0MSC8JQESY"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-0MSC8JQESY');
    </script>
</head>
<body>
<!--loader-->
<div class="loader-wrap">
    <div class="spinner">
        <div class="double-bounce1"></div>
        <div class="double-bounce2"></div>
    </div>
</div>
<!--loader end-->
<!-- main start  -->
<div id="main">
    <!-- header start  -->
    <header class="main-header">
        <!-- logo   -->
        <a href="https://bluebeems.com/" class="logo-holder"><img src="images/bluebeems_logo.png" style="height: 60px;" alt=""></a>
        <!-- logo end  -->
        <!-- search -->
        <!--		<div class="search-button"><i class="far fa-search"></i></div>-->
        <!--		<div class="search-input"><input name="se" id="se" type="text" class="search" placeholder="Search.." /></div>-->
        <!-- search end  -->
        <!--		<div class="sb-button"></div>-->
        <!--		<div class="share-btn showshare"><i class="fal fa-megaphone"></i><span>Share</span></div>-->
        <!-- mobile nav -->
        <div class="nav-button-wrap">
            <div class="nav-button"><span></span><span></span><span></span></div>
        </div>
        <!-- mobile nav end-->
        <!--  navigation -->
        <div class="nav-holder main-menu">
            <nav>
                <ul>
                    <li>
                        <a href="https://bluebeems.com"
                           class="<?php echo ($filel == 'index.php' || strpos($filel, 'index.php') !== false) ? 'act-link' : ''; ?>">Home </a>
                    </li>
                    <li>
                        <a href="https://bluebeems.com/products.php"
                           class="<?php echo ($filel == 'products.php' || strpos($filel, 'products.php') !== false) ? 'act-link' : ''; ?>">Products </a>
                        <!--second level -->
                        <!--						<ul>-->
                        <!--							<li><a href="portfolio.html">Horizontal 2 Columns</a></li>-->
                        <!--							<li><a href="portfolio2.html">Horizontal 3 Columns</a></li>-->
                        <!--							<li><a href="portfolio3.html">Horizontal 1 Columns</a></li>-->
                        <!--							<li><a href="portfolio4.html">Masonry</a></li>-->
                        <!--							<li><a href="portfolio5.html">Masonry 2</a></li>-->
                        <!--							<li><a href="portfolio6.html">Column Grid</a></li>-->
                        <!--							<li>-->
                        <!--								<a href="#">Single </a>-->
                        <!--								-->
                        <!--								<ul>-->
                        <!--									<li><a href="portfolio-single.html">Carousel</a></li>-->
                        <!--									<li><a href="portfolio-single2.html">Fullscreen Slider </a></li>-->
                        <!--									<li><a href="portfolio-single3.html">Column Grid</a></li>-->
                        <!--									<li><a href="portfolio-single4.html">Column Fullwidth</a></li>-->
                        <!--								</ul>-->
                        <!--								-->
                        <!--							</li>-->
                        <!--						</ul>-->
                        <!--second level end-->
                    </li>
                    <li>
                        <a href="https://software.bluebeems.com" target="_blank">Software</a>
                    </li>
                    <li>
                        <a href="https://bluebeems.com/about.php"
                           class="<?php echo ($filel == 'about.php' || strpos($filel, 'about.php') !== false) ? 'act-link' : ''; ?>">About</a>
                    </li>

                    <li>
                        <a href="https://bluebeems.com/contacts.php"
                           class="<?php echo ($filel == 'contacts.php' || strpos($filel, 'contacts.php') !== false) ? 'act-link' : ''; ?>">Where to buy ?
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- navigation  end -->
    </header>
    <!-- header end -->
