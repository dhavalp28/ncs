<?php
$host = "localhost";

$user = "webknigh_bluebeems";

$pwd = "bluebeems@webknight";
$dbname = "webknigh_bluebeems";

$con = mysqli_connect($host, $user, $pwd, $dbname);

class con_data

{

    function con_data2()
    {

        if ($GLOBALS['con']) {
            //  echo "database connected";

        } else {

            //   echo "database not connected";

        }

    }


    function run_qry($qry)
    {

        $res = mysqli_query($GLOBALS['con'], $qry);

        return $res;

    }

}

$address = "";
$logo = "";
$companyname ="";
$obj = new con_data();
$obj->con_data2();
?>
