<?php
//header("Access-Control-Allow-Origin: *");

session_start();

if(isset($_SESSION['phone'])) {
    
    //echo "";
}
else{
    ?>
        <script> location.href = 'login.php'; </script>
    <?php
}

/*
$cookie = $_COOKIE['phone'];
$setcookie_phone =  setcookie('phone',$cookie, time() + (86400 * 30) , "/");

if (isset($setcookie_phone)) {

   // echo "";
    echo $_COOKIE['phone'];
}
else{
    */?><!--
      <script> location.href = 'login.php'; </script>
    --><?php
/*}*/

?>

<!DOCTYPE html>
<html>
<head>
    <title>Bluebeems Software</title>
   <link rel="icon" type="image/png" href="https://software.bluebeems.com/bluebeems.png">
    <script src="https://kit.fontawesome.com/98e12060d9.js" crossorigin="anonymous"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-alpha1/jquery.min.js'></script>
    <link rel="stylesheet" href="style.css">
    <style>

        .previewcontent {
            background: black;
            padding: 10px;
        }

        .impdata {
            border: none;
            background: black;
        }

        #previewtable{
            background: black;
        }

        .border_none {
            border: none !important;
        }

        div.blueTable {
            border: none;
        }

        /* On screens that are 992px wide or less, the background color is blue */
        @media screen and (max-width: 992px) {
            .modal-content {
                width: 60%;
            }

            .modal-content2 {
                width: 60%;
            }
        }

        .redlight {
            box-shadow: 0 0 15px red;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: red;
            visibility: hidden;
        }

        .greenlight {
            box-shadow: 0 0 15px rgb(0, 255, 0);
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: rgb(0, 255, 0);
            visibility: hidden;
        }

        .bluelight {
            box-shadow: 0 0 15px blue;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: blue;
            visibility: hidden;
        }

        .whitelight {
            box-shadow: 0 0 15px white;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: white;
            visibility: hidden;
        }

        .blacklight {
            box-shadow: 0 0 15px black;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: black;
            visibility: hidden;
        }

        .program_count {
            display: inline;
            float: left;
            background: white;
            padding: 1px 10px;
            border-radius: 8px;
        }

        #pm_namem {
            width: 10%;
        }

        #row_valm {
            width: 10%;
        }

        #col_valm {
            width: 10%;
        }

        .no-arrow {
            -moz-appearance: textfield;
        }

        .no-arrow::-webkit-inner-spin-button {
            display: none;
        }

        .no-arrow::-webkit-outer-spin-button,
        .no-arrow::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
    </style>
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-1X30FZR97X"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-1X30FZR97X');
    </script>
</head>
<body style="width:100%">
<div class="preloader">
  <div class="preloader_inner">Sending 0 %
  </div>
  <br/>
  <button style="padding: 8px 18px;border-radius: 10px;background: #e17777fa;color: white;position: absolute;top: 60%;left: 45%;" onclick="cancelsending()">Cancel Sending</button>
</div>

<div class="page show">
<!-- The Modal -->
<div id="add_pj_modal" class="modal">

    <!-- Modal content --> 
    <div class="modal-content">
        <table style="width: 100%;">
            <tr>
                <td><label class="labeldata">Name : </label></td>
                <td><input type="text" id="pm_name" placeholder="Client Name / Project Name"
                           style="width: 100%"/></td>
            </tr>
            <tr>
                <td><label class="labeldata">No of channel : </label></td>
                <td><input type="number" id="col_val" max="108"
                           placeholder="Max:108" onchange="find_rowval(this.value)"
                           min="1" style="width: 100%"/></td>
            </tr>
            
            <tr>
                <td><label class="labeldata">Row : </label></td>
                <td><input type="number" id="row_val" max="36"
                           placeholder="Max:36"
                           min="1" style="width: 100%"/></td>
            </tr>
            <tr style="margin-top: 20px">
                <td colspan="2" style="text-align: center;">
                    <input type="submit" value="Add Project" class="smalladd" onclick="save_modal()"/> &nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Close" class="smalladd" onclick="close_modal()"/></td>
            </tr>
        </table>
    </div>

</div>

<div id="import_modal" class="modal">
    <!-- Modal content -->
    <div class="modal-content2">
        <table style="width: 100%;">
            <tr>
                <td><label class="labeldata">Select File </label></td>
                <td><input type="file" id="file_m" placeholder="select bbm file"
                           style="width: 100%"/></td>
            </tr>
            <tr style="display: none" id="imp_error">
                <td colspan="2" id="error_ele"></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr style="margin-top: 20px">
                <td colspan="2" style="text-align: center;">
                    <input type="submit" value="Import Project" class="smalladd" onclick="imp_data()"/> &nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Close" class="smalladd" onclick="close_modal2()"/></td>
            </tr>
        </table>
    </div>

</div>

<div>
    <div class="fixed">
        <a href="https://bluebeems.com/"><img src="bluebeems.png" style="display: inline;margin-left: auto;margin-right: auto;height: 60px;width: auto;"></a>
        <button class="newadd" onclick="add_project()">Add New Project
        </button>

        <button class="newadd" id="addnewprogram" style="display: none" onclick="add_prodgram()">Add New Program
        </button>

        <h4 style="display: inline;margin-left: 10px">Grid Size</h4>
        <input type="number" id="grid_val" value="53" max="99" onchange="grid_val(this.value)"/>
        <h4 id="bd" style="cursor: pointer;display: inline;" name="1" onclick="change_bd()">Border</h4>

        <button class="newadd" id="export_program" style="display: none" onclick="program_export()">Export
        </button>

        <button class="newadd" onclick="program_import()">Import
        </button>

        <button class="newadd" onclick="connectToBle()">Send
        </button>
        
         <button class="newadd" onclick=" showanimation()">Preview
         </button>

    </div>
    <div id="Program_detail" class="wholediv">
        <div class="collapsible" onclick="collapse2()">
            <h3 style="text-align: center;color:#fff">Project Detail</h3>
        </div>
        <div id="pdcontent" class="content">
            <label class="labeldata">Name : </label><input type="text" id="pm_namem" readonly/>
            <label class="labeldata">Row : </label><input type="number" id="row_valm" readonly/>
            <input type="hidden" id="tabl_no" readonly/>
            <label class="labeldata">Column : </label><input type="number" id="col_valm" readonly/>
            <label class="labeldata">Start Time : </label><input type="time" id="Start_time" value="00:00"/>
            <label class="labeldata">Stop Time : </label><input type="time" id="Stop_time" value="23:59" /> <br/>
            
        </div>
    </div>
    
    <div id="Preview_detail" class="wholediv">
        <div class="collapsible" onclick="collapse2()">
            <div class="program_count">0 / 0</div>
            <h3 style="text-align: center;color:#fff">Preview</h3>
        </div>
        <div id="previewcontent" class="previewcontent">
            <div class="divTable blueTable">
                <div id="previewtable" class="divTableBody">
                    <div class='divTableRow impdata' id="previewdata">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="program_more">
    </div>
</div>
</div>

<script src="aes.js"></script>
<script language="javascript" type="text/javascript" src="BluetoothGUI/libraries/p5.min.js"></script>
<script language="javascript" type="text/javascript" src="BluetoothGUI/libraries/p5.ble.js"></script>
<script language="javascript" type="text/javascript" src="BluetoothGUI/bluetooth_v1_1_10.js"></script>
<script language="javascript" type="text/javascript" src="BluetoothGUI/drawScreen.js"></script>
<script language="javascript" type="text/javascript" src="BluetoothGUI/BluetoothGUI.js"></script>
<script type="">
    startleft = 0;
    startright = 0;
    program = 0;
    copyprogram="N";
    $(document).ready(function () {
        add_project();
    });
    
    function sleep(ms) {
          return new Promise(resolve => setTimeout(resolve, ms));
    }


    async function showanimation() {
        cv = document.getElementById("col_val").value;
        rv = document.getElementById("row_val").value;
        $tno = document.getElementById("tabl_no").value;
        var $tno_p = $tno.split(",");
        $tblcol = "<div class='divTableCell border_none colour_box' style='padding:7px;'> <div class='blacklight'></div></div>";
        for ($cvc = 1; $cvc <= cv; $cvc++) {
            var ele = "sbox" + $tno_p[0] + "_0_" + $cvc;
            prevselected = $("#" + ele).val();
            if (prevselected == "R") {
                $tblcol += "<div class='divTableCell border_none colour_box' style='padding:7px;'> <div class='redlight'></div></div>";
            } else if (prevselected == "G") {
                $tblcol += "<div class='divTableCell border_none colour_box' style='padding:7px;'> <div class='greenlight'></div></div>";
            } else if (prevselected == "B") {
                $tblcol += "<div class='divTableCell border_none colour_box' style='padding:7px;'> <div class='bluelight'></div></div>";
            } else if (prevselected == "W") {
                $tblcol += "<div class='divTableCell border_none colour_box' style='padding:7px;'> <div class='whitelight'></div></div>";
            }
        }
        $("#previewdata").html($tblcol);
        
            $(".divTable.blueTable .divTableBody .divTableCell").css("height", $("#grid_val").val() + "px");
            $(".divTable.blueTable .divTableBody .divTableCell").css("width", $("#grid_val").val() + "px");
            $(".divTable.blueTable .divTableBody .divTableCell").css("min-width", $("#grid_val").val() + "px");
            $(".divTable.blueTable .divTableBody .divTableCell").css("min-height", $("#grid_val").val() + "px");
        $allchildern_array = [];
        $allchildern_fade_array = [];
        $allchildern_fade_ms_array = [];
        $allchildern_rowd_array = [];
        $allchildern_prgd_array = [];
        $counter = 1;
        $data = fetch_table_data2();

        for($nci=0;$nci<$tno_p.length-1;$nci++){
            var ele2 = "fd_" + $tno_p[$nci];
            var ele3 = "fade_d_" + $tno_p[$nci];
            var ele4 = "row_d_" + $tno_p[$nci];
            var ele5 = "prg_d_" + $tno_p[$nci];
            $allchildern_fade_array[$nci]=$("#"+ele2).val()/100;
            $allchildern_fade_ms_array[$nci]=$("#"+ele3).val();
            $allchildern_rowd_array[$nci]=$("#"+ele4).val();
            $allchildern_prgd_array[$nci]=$("#"+ele5).val();
        }

        $("#previewtable").children().each(function () {
            $(this).children().each(function (index) {
                $allchildern_array[$counter] = $(this).children();
                $counter++;
            });
        });

        $dataarray = $data.split(",");
        
        $pno=0;
        for (i = 0; i < $dataarray.length; i++) {
            let childarraycounter = 2;
            $table_number=parseInt(i/rv);
            $table_number_real=$table_number+1;
            $table_total_real=$tno_p.length-1;
            
            $add_ms=parseInt($allchildern_fade_ms_array[$table_number]);
            
            $(".program_count").text($table_number_real + " / " + $table_total_real);
            if(i != 0 ){
                  for (colcount = 0; colcount < $dataarray[i].length; colcount++){
                     if ($dataarray[i].charAt(colcount) == 0 && i != 0 && $dataarray[i - 1].charAt(colcount) != 0) {
                        
                        $allchildern_array[childarraycounter].css({opacity:$allchildern_fade_array[$table_number], visibility: "visible"}).animate({opacity: 0.0},$add_ms);
                        
                    }
                    childarraycounter++;
                }
                await sleep($add_ms);
                $add_ms+=$add_ms;
                childarraycounter=2;
            }
                
            for (colcount = 0; colcount < $dataarray[i].length; colcount++){
                    if ($dataarray[i].charAt(colcount) == 1) {
                        if (i == 0) {
                            $allchildern_array[childarraycounter].css({opacity: 0.0, visibility: "visible"}).animate({opacity: $allchildern_fade_array[$table_number]},parseInt($allchildern_fade_ms_array[$table_number]));
                            
                        } else if ($dataarray[i - 1].charAt(colcount) != 1) {
                            $allchildern_array[childarraycounter].css({opacity: 0.0, visibility: "visible"}).animate({opacity: $allchildern_fade_array[$table_number]},parseInt($allchildern_fade_ms_array[$table_number]));
                        } else {
                            $allchildern_array[childarraycounter].css({opacity: 0.0, visibility: "visible"}).animate({opacity: $allchildern_fade_array[$table_number]},parseInt($allchildern_fade_ms_array[$table_number]));
                        }
                    }
                    
                    childarraycounter++;
                }
                
            await sleep(parseInt($allchildern_rowd_array[$table_number])+$add_ms);
            $table_number_new=parseInt((i+1)/rv);
            if($table_number_new>$table_number){
                await sleep($allchildern_prgd_array[$table_number]);
            }
        }
        
        showanimation();

    }
    
    function find_rowval(colval){
        if(colval<=36){
            document.getElementById("row_val").value = colval;
        }else{
            var divvalue=colval/36;
            
            console.log(divvalue);
            console.log(isFloat(divvalue));
            if(isFloat(divvalue)==true){
                divvalue=parseInt(divvalue)+1;
            }console.log(divvalue);
            document.getElementById("row_val").value = parseInt(colval/divvalue);
        }
    }
    
    function isFloat(x) { return !!(x % 1); }

    function change_bd() {
        console.log($('#bd').attr('name'));
        if ($('#bd').attr('name') == 1) {
            $(".divTable.blueTable .divTableCell, .divTable.blueTable .divTableHead").css("border", "none");
            $("#bd").attr("name", "0");
        } else {
            $(".divTable.blueTable .divTableCell, .divTable.blueTable .divTableHead").css("border", "1px solid #AAAAAA");
            $("#bd").attr("name", "1");
        }
    }
    
    function copyprog(prog){
        copyprogram=prog;
        console.log("copy" + prog);
    }
    
    function pasteprog(prog){
        console.log("paste" + prog);
        if(copyprogram=="N"){
            alert("Please copy program do paste");
        }else{
            rv = document.getElementById("row_val").value;
            cv = document.getElementById("col_val").value;

            
            for (var i = 1; i <= rv; i++) {
                for (var ci = 1; ci <= cv; ci++) {
                    var did = copyprogram + "_" + i + "_" + ci;
                    var did2 = prog + "_" + i + "_" + ci;
                    document.getElementById(did2).innerHTML = document.getElementById(did).innerHTML;
                }
            }
            for (var cfi = 1; cfi <= cv; cfi++) {
                 var didf = 'sbox' + copyprogram + "_" + 0 + "_" + cfi + '';
                 var didf2 = 'sbox' + prog + "_" + 0 + "_" + cfi + '';
                 document.getElementById(didf2).value = document.getElementById(didf).value;    
                change_color(prog,rv,cfi,document.getElementById(didf).value);
                 
            }
        }
    }
    
    function horimirror(prog){
        console.log("horizontal " + prog);
        rv = document.getElementById("row_val").value;
        cv = document.getElementById("col_val").value;

        var narray=[];                            
        for (var i = 1; i <= rv; i++) {
            var datastring="";
            for (var ci = 1; ci <= cv; ci++) {
                var did = prog + "_" + i + "_" + ci;
                datastring+=document.getElementById(did).innerHTML;
            }
            narray.push(datastring);
        }
        
        for (var i = 1; i <= rv; i++) {
            var datasplit=narray[i-1];
            datasplit=datasplit.split("").reverse();
            console.log(datasplit);
            for (var ci = 1; ci <= cv; ci++) {
                var did2 = prog + "_" + i + "_" + ci;
                document.getElementById(did2).innerHTML = datasplit[ci-1];
            }
        }
        
        for (var cfi = 1; cfi <= cv; cfi++) {
            var didf = 'sbox' + prog + "_" + 0 + "_" + cfi + '';
            change_color(prog,rv,cfi,document.getElementById(didf).value);
        }
    
    }
    
    function vertimirror(prog){
        console.log("horizontal " + prog);
        rv = document.getElementById("row_val").value;
        cv = document.getElementById("col_val").value;

        var narray=[];                            
        for (var i = 1; i <= cv; i++) {
            var datastring="";
            for (var ri = 1; ri <= rv; ri++) {
                var did = prog + "_" + ri + "_" + i;
                datastring+=document.getElementById(did).innerHTML;
            }
            narray.push(datastring);
        }
        
        for (var i = 1; i <= cv; i++) {
            var datasplit=narray[i-1];
            datasplit=datasplit.split("").reverse();
            console.log(datasplit);
            for (var ri = 1; ri <= rv; ri++) {
                var did2 = prog + "_" + ri + "_" + i;
                document.getElementById(did2).innerHTML = datasplit[ri-1];
            }
        }
        
        for (var cfi = 1; cfi <= cv; cfi++) {
            var didf = 'sbox' + prog + "_" + 0 + "_" + cfi + '';
            change_color(prog,rv,cfi,document.getElementById(didf).value);
        }
    
    }
    
    function add_prodgram() {
        program++;
        $("#program_more").append('<div id="Program' + program + '" class="wholediv"><div class="collapsible"> <h5 onclick="collapse(' + program + ')" class="tit-left"><i class="fas fa-angle-up"></i> Program ' + program + '</h5><h5 class="tit-left"><div class="del_icon2" onclick="copyprog('+program+')"><i class="fas fa-clone "></i> Copy</div><div class="del_icon2" onclick="pasteprog('+program+')"><i class="fas fa-paste "></i> Paste</div> <div onclick="del_me(this,'+program+')" class="del_icon"><i class="fa fa-trash " aria-hidden="true"></i> Delete</div></h5> <div class="clear-both"></div> </div> <div class="newprogram"> <label class="labeldata">Row Delay in ms:</label><input type="number" max="9999" value="3"  min="0" id="row_d_' + program + '" /><label>Program Delay in ms:</label><input max="9999" min="0" type="number" value="0"  id="prg_d_' + program + '" /><label>Fade in % :</label><input type="number" max="100" value="100"  min="1" id="fd_' + program + '" /></label><label>Fade in ms : </label><input type="number" max="9999" value="3"  min="0" id="fade_d_' + program + '"/><label>Mirror : </label><div style="display:inline"><img src="image/horizontal.png" style="cursor:pointer;margin-left:1%" width="25px" onclick="vertimirror('+program+')" /></div><div  style="display:inline"><img src="image/vertical.png" style="cursor:pointer;margin-left:1%" width="25px" onclick="horimirror('+program+')" /></div></div> <div id="p_con' + program + '" class="content"> <div class="divTable blueTable"><div id="table_' + program + '" class="divTableBody"></div></div> </div></div>');

        document.getElementById("tabl_no").value += program + ",";

        change_table(program);

        document.getElementById("addnewprogram").style.display = "inline";
        document.getElementById("export_program").style.display = "inline";

        var val = $("#grid_val").val();
        if (val <= 16) {
            val = 16;
        }

        $(".divTableCell").css("height", val + "px");
        $(".divTableCell").css("width", val + "px");
        $(".divTableCell").css("min-width", val + "px");
        $(".divTableCell").css("min-height", val + "px");
        if (val < 40) {
            $(".selectbox").css("display", "none");
        } else {
            $(".selectbox").css("display", "block");
        }
        if (val < 25) {
            $(".colour_box").css("display", "none");
        } else {
            $(".colour_box").css("display", "table-cell");
        }
    }

    function add_prodgram_imp($datastring) {
        program++;
        $("#program_more").append('<div id="Program' + program + '" class="wholediv"><div class="collapsible"> <h5 onclick="collapse(' + program + ')" class="tit-left"><i class="fas fa-angle-up"></i> Program ' + program + '</h5><h5 class="tit-left"><div class="del_icon2" onclick="copyprog('+program+')"><i class="fas fa-clone "></i> Copy</div><div class="del_icon2" onclick="pasteprog('+program+')"><i class="fas fa-paste "></i> Paste</div> <div class="del_icon" onclick="del_me(this,'+program+')"><i class="fa fa-trash " aria-hidden="true" ></i> Delete</div></h5> <div class="clear-both"></div> </div> <div class="newprogram"> <label class="labeldata">Row Delay in ms:</label><input type="number" max="9999" value="3"  min="0" id="row_d_' + program + '" /><label>Program Delay in ms:</label><input max="9999" min="0" type="number" value="0"  id="prg_d_' + program + '" /><label>Fade in % :</label><input type="number" max="100" value="100"  min="1" id="fd_' + program + '" /></label><label>Fade in ms : </label><input type="number" max="9999" value="3"  min="0" id="fade_d_' + program + '"/><label>Mirror : </label><div style="display:inline"><img src="image/horizontal.png" style="cursor:pointer;margin-left:1%" width="25px" onclick="vertimirror('+program+')" /></div><div  style="display:inline"><img src="image/vertical.png" style="cursor:pointer;margin-left:1%" width="25px" onclick="horimirror('+program+')" /></div></div> <div id="p_con' + program + '" class="content"> <div class="divTable blueTable"><div id="table_' + program + '" class="divTableBody"></div></div> </div></div>');

        document.getElementById("tabl_no").value += program + ",";

        change_table_imp(program, $datastring);

        document.getElementById("addnewprogram").style.display = "inline";
        document.getElementById("export_program").style.display = "inline";

        var val = $("#grid_val").val();
        if (val <= 16) {
            val = 16;
        }

        $(".divTableCell").css("height", val + "px");
        $(".divTableCell").css("width", val + "px");
        $(".divTableCell").css("min-width", val + "px");
        $(".divTableCell").css("min-height", val + "px");
        if (val < 40) {
            $(".selectbox").css("display", "none");
        } else {
            $(".selectbox").css("display", "block");
        }
        if (val < 25) {
            $(".colour_box").css("display", "none");
        } else {
            $(".colour_box").css("display", "table-cell");
        }
    }

    function add_project() {
        document.getElementById("add_pj_modal").style.display = "block";
    }

    function program_import() {
        document.getElementById("import_modal").style.display = "block";
    }

    function collapse(program) {
        $("#p_con" + program).slideToggle();
    }

    function collapse2() {
        $("#pdcontent").slideToggle();
    }

    $("body").mousedown(function (event) {
        if( window.screen.availWidth>768){
            if (event.target.className == "divTableCell") {
                switch (event.which) {
                    case 1:
                        startleft = 1;
                        change_value(event.target.id);
                        break;
                    case 3:
                        startright = 1;
                        change_value(event.target.id);
                        break;
                }
            }
        }
    });
    $("body").mouseup(function () {
        startleft = 0;
        startright = 0;
    });
    $("body").on("contextmenu", function (e) {
        return false;
    });

    function grid_val(val) {
        if (val >= 16) {
            $(".divTableCell").css("height", val + "px");
            $(".divTableCell").css("width", val + "px");
            $(".divTableCell").css("min-width", val + "px");
            $(".divTableCell").css("min-height", val + "px");
            if (val < 40) {
                $(".selectbox").css("display", "none");
            } else {
                $(".selectbox").css("display", "block");
            }
            if (val < 25) {
                $(".colour_box").css("display", "none");
            } else {
                $(".colour_box").css("display", "table-cell");
            }
        } else {
            $("#grid_val").val("16");
        }
    }

    function change_table(index) {
        var rows = "";
        rv = document.getElementById("row_val").value;
        cv = document.getElementById("col_val").value;
        if (cv == "") {
            cv = 0;
        }
        if (cv >= 108) {
            cv = 108;
            document.getElementById("col_val").value = 108;
        }

        if (rv >= 36) {
            rv = 36;
            document.getElementById("row_val").value = 36;
        }

        if (rv == "") {
            rv = 0;
        }

        for (var i = 0; i <= rv; i++) {
            rows += "<div class='divTableRow'>";
            if (i == 0) {
                rows += "<div class='divTableCell colour_box'>&nbsp;</div>";
            } else {
                rows += "<div class='divTableCell colour_box'><input type='checkbox' onchange=change_checkbox_row_color(" + index + "," + i + "," + cv + ",event) />" + i + "</div>";
            }
            var prevselected = "N";
            for (var ci = 1; ci <= cv; ci++) {
                var did = '"' + index + "_" + i + "_" + ci + '"';
                if (i == 0) {
                    if(prevselected=="N"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option selected>R</option><option>G</option><option>B</option><option>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";
                        prevselected="R";
                    }else if(prevselected=="R"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option>R</option><option selected>G</option><option>B</option><option>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";
                        prevselected="G";
                    }else if(prevselected=="G"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option>R</option><option>G</option><option selected>B</option><option>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";
                        prevselected="N";
                    }
                } else {
                    if( window.screen.availWidth>768){
                    rows += "<div class='divTableCell' id='" + index + "_" + i + "_" + ci + "' style='color: rgba(0, 0, 0, 0);' onmouseenter='change_value(" + did + ")'>0</div>";
                    }else{
                        rows += "<div class='divTableCell' id='" + index + "_" + i + "_" + ci + "' style='color: rgba(0, 0, 0, 0);'  onclick='change_value_onclick(" + did + ",this.value)'>0</div>";
                    }
                    
                    
                }
            }
            rows += "</div>";
        }

        document.getElementById("row_valm").value = rv;
        document.getElementById("col_valm").value = cv;
        document.getElementById("table_" + index).innerHTML = rows;

        var val = $("#grid_val").val();
        if (val <= 16) {
            val = 16;
        }

        $(".divTableCell").css("height", val + "px");
        $(".divTableCell").css("width", val + "px");
        $(".divTableCell").css("min-width", val + "px");
        $(".divTableCell").css("min-height", val + "px");
        if (val < 40) {
            $(".selectbox").css("display", "none");
        } else {
            $(".selectbox").css("display", "block");
        }
        if (val < 25) {
            $(".colour_box").css("display", "none");
        } else {
            $(".colour_box").css("display", "table-cell");
        }
    }

    function change_table_imp(index, $datastring) {
        var rows = "";
        rv = document.getElementById("row_val").value;
        cv = document.getElementById("col_val").value;
        if (cv == "") {
            cv = 0;
        }
        if (cv >= 108) {
            cv = 108;
            document.getElementById("col_val").value = 108;
        }

        if (rv >= 36) {
            rv = 36;
            document.getElementById("row_val").value = 36;
        }

        if (rv == "") {
            rv = 0;
        }
        console.log($datastring);
        var $datastringa = $datastring.split(",");
        var $dropdowndata = $datastringa[rv].split("");

        for (var i = 0; i <= rv; i++) {
            var $rowdata = "";
            rows += "<div class='divTableRow'>";
            if (i == 0) {
                rows += "<div class='divTableCell colour_box'>&nbsp;</div>";
            } else {
                $rowdata = $datastringa[i - 1].split("");
                rows += "<div class='divTableCell colour_box'><input type='checkbox' onchange=change_checkbox_row_color(" + index + "," + i + "," + cv + ",event) />" + i + "</div>";
            }
            for (var ci = 1; ci <= cv; ci++) {
                var did = '"' + index + "_" + i + "_" + ci + '"';
                if (i == 0) {
                    $d_s=$dropdowndata[ci - 1];
                    if($d_s=="R"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option selected>R</option><option>G</option><option>B</option><option>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";    
                    }else if($d_s=="G"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option>R</option><option selected>G</option><option>B</option><option>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";
                    }else if($d_s=="B"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option>R</option><option>G</option><option selected>B</option><option>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";
                    }else if($d_s=="W"){
                        rows += "<div class='divTableCell colour_box'><select class='selectbox' onchange=change_color(" + index + "," + rv + "," + ci + ",this.value) id='sbox" + index + "_" + i + "_" + ci + "'><option>R</option><option>G</option><option>B</option><option selected>W</option></select> <input type='checkbox' onchange=change_checkbox_col_color(" + index + "," + rv + "," + ci + ",event) /> " + ci + "</div>";
                    }
                    
                } else {
                    
                    if( window.screen.availWidth>768){
                    rows += "<div class='divTableCell' id='" + index + "_" + i + "_" + ci + "' style='color: rgba(0, 0, 0, 0);' onmouseenter='change_value(" + did + ")' >" + $rowdata[ci - 1] + "</div>";
                    }else{
                        rows += "<div class='divTableCell' id='" + index + "_" + i + "_" + ci + "' style='color: rgba(0, 0, 0, 0);' onclick='change_value_onclick(" + did + ",this.value)' >" + $rowdata[ci - 1] + "</div>";
                    }
                }
            }
            rows += "</div>";
        }

        document.getElementById("row_valm").value = rv;
        document.getElementById("col_valm").value = cv;
        document.getElementById("table_" + index).innerHTML = rows;


        for (var lasttracker = 1; lasttracker <= cv; lasttracker++) {
            change_color(index, rv, lasttracker, $dropdowndata[lasttracker - 1]);
        }

        var val = $("#grid_val").val();
        if (val <= 16) {
            val = 16;
        }

        $(".divTableCell").css("height", val + "px");
        $(".divTableCell").css("width", val + "px");
        $(".divTableCell").css("min-width", val + "px");
        $(".divTableCell").css("min-height", val + "px");
        if (val < 40) {
            $(".selectbox").css("display", "none");
        } else {
            $(".selectbox").css("display", "block");
        }
        if (val < 25) {
            $(".colour_box").css("display", "none");
        } else {
            $(".colour_box").css("display", "table-cell");
        }
    }

    function change_color(index, rv, ci, sv) {
        for (var i = 1; i <= rv; i++) {
            var ele = index + "_" + i + "_" + ci;
            if (document.getElementById(ele).innerHTML == "1") {
                switch (sv) {
                    case "R":
                        document.getElementById(ele).style.backgroundColor = "#ff0000";
                        break;
                    case "G":
                        document.getElementById(ele).style.backgroundColor = "#00ff00";
                        break;
                    case "B":
                        document.getElementById(ele).style.backgroundColor = "#0000ff";
                        break;
                    case "W":
                        document.getElementById(ele).style.backgroundColor = "#000";
                        break;
                    default:
                        break;
                }
            }
            else{
                document.getElementById(ele).style.backgroundColor = "#EEEEEE";
            }
        }
    }

    function change_checkbox_row_color(index, srv, cv, sv) {
        for (var ci = 1; ci <= cv; ci++) {
            var ele = index + "_" + srv + "_" + ci;
            if (sv.target.checked) {
                document.getElementById(ele).innerHTML = "1";
                switch (document.getElementById("sbox" + index + "_" + "0" + "_" + ci).value) {
                    case "R":
                        document.getElementById(ele).style.backgroundColor = "#ff0000";
                        break;
                    case "G":
                        document.getElementById(ele).style.backgroundColor = "#00ff00";
                        break;
                    case "B":
                        document.getElementById(ele).style.backgroundColor = "#0000ff";
                        break;
                    case "W":
                        document.getElementById(ele).style.backgroundColor = "#000";
                        break;
                    default:
                        break;
                }
            } else {
                document.getElementById(ele).innerHTML = "0";
                document.getElementById(ele).style.backgroundColor = "#EEEEEE";
            }
        }
    }

    function change_checkbox_col_color(index, rv, ci, sv) {
        for (var i = 1; i <= rv; i++) {
            var ele = index + "_" + i + "_" + ci;
            if (sv.target.checked) {
                document.getElementById(ele).innerHTML = "1";
                switch (document.getElementById("sbox" + index + "_" + "0" + "_" + ci).value) {
                    case "R":
                        document.getElementById(ele).style.backgroundColor = "#ff0000";
                        break;
                    case "G":
                        document.getElementById(ele).style.backgroundColor = "#00ff00";
                        break;
                    case "B":
                        document.getElementById(ele).style.backgroundColor = "#0000ff";
                        break;
                    case "W":
                        document.getElementById(ele).style.backgroundColor = "#000";
                        break;
                    default:
                        break;
                }
            } else {
                document.getElementById(ele).innerHTML = "0";
                document.getElementById(ele).style.backgroundColor = "#EEEEEE";
            }
        }
    }

    function change_value(ele) {
        if (startleft == 1) {
            var res = ele.split("_");
            switch (document.getElementById("sbox" + res[0] + "_" + "0" + "_" + res[2]).value) {
                case "R":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#ff0000";
                    break;
                case "G":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#00ff00";
                    break;
                case "B":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#0000ff";
                    break;
                case "W":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#000";
                    break;
                default:
                    break;
            }
        } else if (startright == 1) {
            document.getElementById(ele).innerHTML = "0";
            document.getElementById(ele).style.backgroundColor = "#EEEEEE";
        }
        // if(document.getElementById(ele).innerHTML=="1"){
        //     document.getElementById(ele).innerHTML = "0";
        //     document.getElementById(ele).style.backgroundColor = "#EEEEEE";
        // }else{
        //     document.getElementById(ele).innerHTML = "1";
        //     document.getElementById(ele).style.backgroundColor = "#000";
        // }
    }
    
    function change_value_onclick(ele,value_this) {
        opps_value=document.getElementById(ele).innerHTML;
        if (opps_value == 0) {
            var res = ele.split("_");
            switch (document.getElementById("sbox" + res[0] + "_" + "0" + "_" + res[2]).value) {
                case "R":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#ff0000";
                    break;
                case "G":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#00ff00";
                    break;
                case "B":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#0000ff";
                    break;
                case "W":
                    document.getElementById(ele).innerHTML = "1";
                    document.getElementById(ele).style.backgroundColor = "#000";
                    break;
                default:
                    break;
            }
        } else if (opps_value == 1) {
            document.getElementById(ele).innerHTML = "0";
            document.getElementById(ele).style.backgroundColor = "#EEEEEE";
        }
        // if(document.getElementById(ele).innerHTML=="1"){
        //     document.getElementById(ele).innerHTML = "0";
        //     document.getElementById(ele).style.backgroundColor = "#EEEEEE";
        // }else{
        //     document.getElementById(ele).innerHTML = "1";
        //     document.getElementById(ele).style.backgroundColor = "#000";
        // }
    }

    function close_modal() {
        document.getElementById("add_pj_modal").style.display = "none";
    }

    function del_me(ele,pgram){
        console.log(ele);
        console.log($(ele).parent().parent().parent());
        $(ele).parent().parent().parent().remove();
        if(program==pgram){
            program--;
        }
        $tno = document.getElementById("tabl_no").value;
          var $tno_ps = $tno.split(",");
          var $char = $tno_ps.length - 1;
          
            for( var ic = 0; ic < $tno_ps.length; ic++){ 
    
                if ( $tno_ps[ic] == pgram) { 
            
                    $tno_ps.splice(ic, 1); 
                }
            
            }
            document.getElementById("tabl_no").value=$tno_ps.toString();
            console.log($tno_ps.toString());
    }

    function close_modal2() {
        document.getElementById("import_modal").style.display = "none";
    }

    function save_modal() {
        rv = document.getElementById("row_val").value;
        cv = document.getElementById("col_val").value;
        pmv = document.getElementById("pm_name").value;

        pmv = pmv.replace(/[^a-zA-Z0-9]/g, '');
        if (rv == "" || cv == "" || pmv == "") {
            alert("Please enter proper value");
            return;
        }

        program = 0;
        if (cv == "") {
            cv = 0;
        }
        if (cv >= 108) {
            cv = 108;
            document.getElementById("col_val").value = 108;
        }

        if (rv >= 36) {
            rv = 36;
            document.getElementById("row_val").value = 36;
        }

        if (rv == "") {
            rv = 0;
        }
        document.getElementById("tabl_no").value= "";
        document.getElementById("program_more").innerHTML = "";
        document.getElementById("row_valm").value = rv;
        document.getElementById("col_valm").value = cv;
        document.getElementById("pm_namem").value = pmv.toString();
        startleft = 0;
        startright = 0;
        program = 0;
        copyprogram="N";
        add_prodgram();
        document.getElementById("add_pj_modal").style.display = "none";
    }

    function program_export() {
        if(manage_validation()){
            $rv = document.getElementById("row_val").value;
            $cv = document.getElementById("col_val").value;
            $pmv = document.getElementById("pm_name").value;
            $pmv = $pmv.replace(/[^a-zA-Z0-9]/g, '');
            if ($rv == "" || $cv == "" || $pmv == "") {
                alert("Please add program");
                return;
            }
            $Start_time = document.getElementById("Start_time").value;
            $Stop_time = document.getElementById("Stop_time").value;
    

            $tno = document.getElementById("tabl_no").value;
            var $tno_p = $tno.split(",");

            $char = $tno_p.length - 1;
            $return = {
                name: $pmv,
                row: $rv,
                cv: $cv,
                start_time: $Start_time,
                stop_time: $Stop_time,
                char: $char,
                data: [fetch_table_data()],
                upper_data: [fetch_upper_data()]
            };
            console.log(JSON.stringify($return));
            var encrypted = CryptoJS.AES.encrypt(JSON.stringify($return), "WebKnight,[;.]'/");
            download($pmv + ".bbm", encrypted);
        }else{
            alert("Please enter all necessary detail");
            return 0;
        }
    }

    function setheaderdata(char, datashare) {
        var data_array = datashare.split(",");
        document.getElementById("row_d_" + char).value = data_array[0];
        document.getElementById("prg_d_" + char).value = data_array[1];
        document.getElementById("fd_" + char).value = data_array[2];
        document.getElementById("fade_d_" + char).value = data_array[3];
    }

    function imp_data() {
        var fileInput = document.getElementById('file_m');
        var file = fileInput.files[0];

        if (file == "undefined" || file == "") {
            alert("Kindly select file first.");
            return;
        }

        var reader = new FileReader();

        reader.onload = function (e) {
            try {
                $final_text = reader.result;
                var code = CryptoJS.AES.decrypt($final_text, "WebKnight,[;.]'/");
                var decryptedMessage = code.toString(CryptoJS.enc.Utf8);
                var obj = JSON.parse(decryptedMessage);
                console.log(obj);
                console.log(decryptedMessage);
                startleft = 0;
                startright = 0;
                program = 0;
                
                document.getElementById("program_more").innerHTML = "";
                document.getElementById("row_val").value = obj.row;
                document.getElementById("col_val").value = obj.cv;
                document.getElementById("pm_name").value = obj.name;
                document.getElementById("row_valm").value = obj.row;
                document.getElementById("col_valm").value = obj.cv;
                document.getElementById("pm_namem").value = obj.name;
                document.getElementById("Start_time").value = obj.start_time;
                document.getElementById("Stop_time").value = obj.stop_time;
                
                $.each(obj.data[0], function (key, item) {
                    add_prodgram_imp(item);
                });

                $start_c = 1;
                $.each(obj.upper_data[0], function (key, item) {
                    setheaderdata($start_c, item);
                    $start_c++;
                });

                close_modal2();
            } catch (error) {
                console.log(error);
                document.getElementById("error_ele").innerText = "File not supported!";
                document.getElementById("imp_error").style.display = "block"
            }
        }
        reader.readAsText(file);
    }

    function fetch_table_data() {
        $rv = document.getElementById("row_val").value;
        $cv = document.getElementById("col_val").value;
        $pmv = document.getElementById("pm_name").value;
        $pmv = $pmv.replace(/[^a-zA-Z0-9]/g, '');
        if ($rv == "" || $cv == "" || $pmv == "") {
            alert("Please add program");
            return;
        }
        $tno = document.getElementById("tabl_no").value;
        var $tno_p = $tno.split(",");

        $char = $tno_p.length - 1;

        $data = "{";

        for ($char_c = 0; $char_c < $char; $char_c++) {
            $jk = "";
            for (var i = 1; i <= rv; i++) {
                for (var ci = 1; ci <= cv; ci++) {
                    var did = $tno_p[$char_c] + "_" + i + "_" + ci;
                    console.log(did);
                    $jk += document.getElementById(did).innerHTML;
                }
                $jk += ",";
            }
            for (var cfi = 1; cfi <= cv; cfi++) {
                var didf = 'sbox' + $tno_p[$char_c] + "_" + 0 + "_" + cfi + '';
                $jk += document.getElementById(didf).value;
            }

            if ($char_c == $char - 1)
                $data += '"data' + $char_c + '":"' + $jk + '"';
            else
                $data += '"data' + $char_c + '":"' + $jk + '",';
        }
        $data += '}';
        return JSON.parse($data);
    }
    
     function fetch_table_data2() {
        $rv = document.getElementById("row_val").value;
        $cv = document.getElementById("col_val").value;
        $pmv = document.getElementById("pm_name").value;
        $pmv = $pmv.replace(/[^a-zA-Z0-9]/g, '');
        if ($rv == "" || $cv == "" || $pmv == "") {
            alert("Please add program");
            return;
        }
        $tno = document.getElementById("tabl_no").value;
        var $tno_p = $tno.split(",");

        $char = $tno_p.length - 1;

        $data = "";

        for ($char_c = 0; $char_c < $char; $char_c++) {
            $jk = "";
            for (var i = 1; i <= rv; i++) {
                for (var ci = 1; ci <= cv; ci++) {
                    var did = $tno_p[$char_c] + "_" + i + "_" + ci;
                    $jk += document.getElementById(did).innerHTML;
                }
                $jk += ",";
            }
            $data += $jk;
        }
        $data = $data.slice(0, -1);
        return $data;
    }

    function fetch_upper_data() {
        $rv = document.getElementById("row_val").value;
        $cv = document.getElementById("col_val").value;
        $pmv = document.getElementById("pm_name").value;
        $pmv = $pmv.replace(/[^a-zA-Z0-9]/g, '');
        if ($rv == "" || $cv == "" || $pmv == "") {
            alert("Please add program");
            return;
        }
        $tno = document.getElementById("tabl_no").value;
        var $tno_p = $tno.split(",");

        $char = $tno_p.length - 1;

        $data = "{";

        for ($char_c = 1; $char_c <= $char; $char_c++) {
            $jk = document.getElementById("row_d_" + $tno_p[$char_c-1]).value + "," +
                document.getElementById("prg_d_" + $tno_p[$char_c-1]).value + "," +
                document.getElementById("fd_" + $tno_p[$char_c-1]).value + "," +
                document.getElementById("fade_d_" + $tno_p[$char_c-1]).value + ",";


            if ($char_c == $char)
                $data += '"data' + $char_c + '":"' + $jk + '"';
            else
                $data += '"data' + $char_c + '":"' + $jk + '",';
        }
        $data += '}';
        return JSON.parse($data);
    }

    function download(filename, text) {
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }

    function manage_validation() {
        $validation = true;
        $rv = document.getElementById("row_val").value;
        $cv = document.getElementById("col_val").value;
        $pmv = document.getElementById("pm_name").value;
        $pmv = $pmv.replace(/[^a-zA-Z0-9]/g, '');
        if ($rv == "" || $cv == "" || $pmv == "") {
            $validation = false;
            return $validation;
        }
        $Start_time = document.getElementById("Start_time").value;
        $Stop_time = document.getElementById("Stop_time").value;
        if ($Start_time == "" || $Stop_time == "") {
            $validation = false;
            return $validation;
        }
        $tno = document.getElementById("tabl_no").value;
        var $tno_p = $tno.split(",");

        $char = $tno_p.length - 1;

        for ($char_c = 1; $char_c <= $char; $char_c++) {
            if (document.getElementById("row_d_" + $tno_p[$char_c-1]).value  == "" ||
                document.getElementById("prg_d_" + $tno_p[$char_c-1]).value  == "" ||
                document.getElementById("fd_" + $tno_p[$char_c-1]).value =="" ||
                document.getElementById("fade_d_" +$tno_p[$char_c-1]).value =="" ){
                $validation = false;
                return $validation;
            }
        }

        return $validation;
    }

    window.onclick = function (event) {
        if (event.target == document.getElementById("add_pj_modal")) {
            document.getElementById("add_pj_modal").style.display = "none";
        }
    }
    
/*    loader();

document.querySelector('.btn').onclick = loader;

function loader(_success) {
  var obj = document.querySelector('.preloader'),
  inner = document.querySelector('.preloader_inner'),
  page = document.querySelector('.page');
  obj.classList.add('show');
  page.classList.remove('show');
  var w = 0,
  t = setInterval(function () {
    w = w + 1;
    inner.textContent = w + '%';
    if (w === 100) {
      obj.classList.remove('show');
      page.classList.add('show');
      clearInterval(t);
      w = 0;
      if (_success) {
        return _success();
      }
    }
  }, 20);
}*/
</script>
</body>
</html>
