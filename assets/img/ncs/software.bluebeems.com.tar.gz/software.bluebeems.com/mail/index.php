<?php
/*use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->Host = 'mail.webknight.co.in';
    $mail->SMTPAuth = false;
    $mail->SMTPAutoTLS = false;
    $mail->Username = 'support@embedmart.com';
    $mail->Password = 'support@embedmart';

    $mail->Port = 587;
    $mail->setFrom('noreply@embedmart.com', 'Embedmart');
    $mail->addAddress('nkthakor22.97@gmail.com');

    $body = '<p><strong>Hello</strong>This is shivam testing</p>';

    $mail->isHTML(true);
    $mail->Subject = 'Here is the subject';
    $mail->Body = $body;
    $mail->AltBody = strip_tags($body);

    $mail->send();
    
    echo 'Message has been sent';
} catch (Exception $e)
{
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}*/

include "mail_sender.php";

send_reg_mail();