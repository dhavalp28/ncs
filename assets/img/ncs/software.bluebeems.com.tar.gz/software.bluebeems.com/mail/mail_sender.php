<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/vendor/autoload.php';

function send_reg_mail()
{

    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();
        $mail->Host = 'mail.thesaturnoverseas.com';
        $mail->SMTPAuth = false;
        $mail->SMTPAutoTLS = false;
        $mail->Username = 'support@blicksell.com';
        $mail->Password = 'support@blicksell';

        $mail->Port = 587;
        $mail->setFrom('noreply@blicksell.com', 'BlickSell');
        $mail->addAddress('nkthakor22.97@gmail.com');

        $body = '<p><strong>Hello</strong>This is shivam testing</p>';

        $mail->isHTML(true);
        $mail->Subject = 'Here is the subject';
        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);

        $mail->send();

        echo 'Message has been sent';
    } catch (Exception $e)
    {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

}

?>
