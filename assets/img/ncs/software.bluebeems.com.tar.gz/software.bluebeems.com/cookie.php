<?php

$phone = "12345678";
// serialize($phone)
//$mobileno = $phone;

$_COOKIE['phone'] = $phone ;

$setcookie_phone =  setcookie('phone', serialize($_COOKIE['phone']) , time() + (86400 * 30) , "/");

echo $_COOKIE['phone'];
/*echo $_COOKIE['phone'];

unset($_COOKIE['phone']);

if (isset($_COOKIE['phone'])){
*/?><!--

    <script> location.href = 'index.php'; </script>

    --><?php
/*}

unset($_COOKIE['phone']);*/

?>